/* ==========================================================================
   Tecnobox · kit v2 — comportamiento mínimo, sin dependencias.
   Va al tema de Shopify como assets/tb-kit.js (con defer). Todo por atributos
   data-*, así las secciones Liquid no necesitan JS propio.
     data-tb-abrir-cajon      abre el cajón del carrito
     data-tb-cerrar-cajon     lo cierra (también Esc y el velo)
     data-tb-cantidad         stepper: botones [data-tb-menos] [data-tb-mas] y [data-tb-valor]
     data-tb-cinta            cinta de envío: data-meta (centavos) y data-total (centavos)
     window.tbTicket(opts)    imprime un ticket (aviso) abajo a la derecha
   ========================================================================== */
(function () {
  "use strict";
  var pesos = function (centavos) {
    return "$" + Math.round(centavos / 100).toLocaleString("es-CL");
  };

  /* ——— Cajón del carrito ——— */
  function cajon() { return document.querySelector("[data-tb-cajon]"); }
  function abrirCajon() {
    var c = cajon(); if (!c) return;
    c.setAttribute("data-abierto", "true");
    c.removeAttribute("inert");
    var foco = c.querySelector("[data-tb-cerrar-cajon], button, a");
    if (foco) foco.focus();
    document.documentElement.style.overflow = "hidden";
  }
  function cerrarCajon() {
    var c = cajon(); if (!c) return;
    c.setAttribute("data-abierto", "false");
    c.setAttribute("inert", "");
    document.documentElement.style.overflow = "";
  }
  document.addEventListener("click", function (e) {
    var t = e.target.closest ? e.target : e.target.parentElement;
    if (t.closest("[data-tb-abrir-cajon]")) { e.preventDefault(); abrirCajon(); }
    else if (t.closest("[data-tb-cerrar-cajon]")) { e.preventDefault(); cerrarCajon(); }
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") cerrarCajon(); });

  /* ——— Cantidad ——— */
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-tb-menos], [data-tb-mas]");
    if (!b) return;
    var caja = b.closest("[data-tb-cantidad]"); if (!caja) return;
    var v = caja.querySelector("[data-tb-valor]");
    var n = parseInt(v.value || v.textContent, 10) || 1;
    n = b.hasAttribute("data-tb-mas") ? n + 1 : Math.max(1, n - 1);
    if ("value" in v && v.tagName === "INPUT") v.value = n; else v.textContent = n;
    caja.dispatchEvent(new CustomEvent("tb:cantidad", { bubbles: true, detail: n }));
  });

  /* ——— Cinta de envío ——— */
  function pintarCinta(el) {
    var meta = parseInt(el.getAttribute("data-meta"), 10) || 2000000;
    var total = parseInt(el.getAttribute("data-total"), 10) || 0;
    var avance = Math.min(1, total / meta);
    el.style.setProperty("--avance", avance.toFixed(3));
    el.setAttribute("data-lista", avance >= 1 ? "true" : "false");
    var texto = el.querySelector("[data-tb-cinta-texto]");
    if (texto) {
      var regalo = el.getAttribute("data-regalo") || "300000";
      texto.innerHTML = avance >= 1
        ? "Listo: te regalamos <b>" + pesos(+regalo) + "</b> en tu envío."
        : "Te faltan <b>" + pesos(meta - total) + "</b> para que te regalemos <b>" + pesos(+regalo) + "</b> en tu envío.";
    }
  }
  window.tbPintarCintas = function () { document.querySelectorAll("[data-tb-cinta]").forEach(pintarCinta); };

  /* ——— Tickets (avisos) ——— */
  window.tbTicket = function (o) {
    o = o || {};
    var pila = document.querySelector(".tb-tickets");
    if (!pila) { pila = document.createElement("div"); pila.className = "tb-tickets"; pila.setAttribute("aria-live", "polite"); document.body.appendChild(pila); }
    var hora = new Date().toLocaleTimeString("es-CL", { hour: "2-digit", minute: "2-digit" });
    var t = document.createElement("div");
    t.className = "tb-ticket tb-ticket--" + (o.tono || "bien");
    t.setAttribute("role", o.tono === "grave" ? "alert" : "status");
    t.innerHTML = '<div class="tb-ticket__cabeza"><span class="tb-ticket__estado">' + (o.estado || "Listo") + "</span><span>Tecnobox · " + hora + "</span></div>" +
      '<strong class="tb-ticket__titulo"></strong>' + (o.texto ? '<p class="tb-ticket__texto"></p>' : "") +
      (o.deshacer ? '<div class="tb-ticket__acciones"><button type="button" class="tb-tecla tb-tecla--papel tb-tecla--s">Deshacer</button></div>' : "");
    t.querySelector(".tb-ticket__titulo").textContent = o.titulo || "";
    if (o.texto) t.querySelector(".tb-ticket__texto").textContent = o.texto;
    var quitar = function () { t.style.transition = "opacity .25s"; t.style.opacity = "0"; setTimeout(function () { t.remove(); }, 260); };
    if (o.deshacer) t.querySelector("button").addEventListener("click", function () { o.deshacer(); quitar(); });
    pila.appendChild(t);
    while (pila.children.length > 3) pila.firstChild.remove();
    setTimeout(quitar, o.duracion || 4200);
    return t;
  };

  function iniciar() {
    window.tbPintarCintas();
    var c = cajon(); if (c && c.getAttribute("data-abierto") !== "true") c.setAttribute("inert", "");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();
