# Tecnobox · kit Shopify V2 — "Todo llega en una caja"

Guion visual: https://tecnobox-cl.github.io/guion-visual/

## Instalar (tema duplicado primero)
1. Tienda online -> Temas -> ... -> Duplicar. Se prueba en la copia.
2. Editar código: sube `assets/`, `snippets/` y `sections/` a sus carpetas.
   Todo lleva prefijo `tb-`: no pisa archivos del tema.
3. En `layout/theme.liquid`, antes de `</head>`:  `{% render 'tb-head' %}`
   y antes de `</body>`:  `{% render 'tb-cajon' %}`
4. Usa las piezas:
   - `{% render 'tb-caja', product: product %}`
   - `{% render 'tb-tecla', texto: 'Agregar al carro', tipo: 'submit', tecla: '⏎' %}`
   - `{% render 'tb-etiqueta', variante: product.selected_or_first_available_variant %}`
   - `{% render 'tb-cinta' %}`
   - Sección en el editor: "Tecnobox · Cajas".

## Reglas
- Una sola tecla lima por pantalla (comprar). Texto sobre lima siempre carbón.
- El % de descuento sale de compare_at_price; sin precio anterior no hay descuento.
- `data-tb-tema="oscuro"` en un contenedor lo pasa a la escena de neón.
- Sin dependencias: tb-kit.js se engancha por atributos `data-tb-*`.
